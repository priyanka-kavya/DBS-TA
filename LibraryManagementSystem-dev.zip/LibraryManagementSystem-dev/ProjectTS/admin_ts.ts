class AdminClass
{
    constructor()
    {

    }

    private username:String = "admin1";
    private pass:String = "password";

    public numberOfBooks:number = 20;
    public delayFine = 10;

    public addLibrarian = function():string
    {
        return "New Librarian Added";
    }

    public removeLibrarian = function(librarian:string):string
    {
        return librarian + " Librarian Removed";
    }

    public setFine = function(fine:number):string
    {
        this.delayFine = fine;

        return "Fine for delay is Rs." + this.delayFine + " per day";
    }

    public getStock = function():string
    {
        return "The number of books available are " + this.numberOfBooks;
    }

    public reduceBookCount = function():string
    {
        this.numberOfBooks = this.numberOfBooks - 1;

        return "Now the number of books are " + this.numberOfBooks;
    }
    
    public increaseBookCount = function():string
    {
        this.numberOfBooks = this.numberOfBooks + 1;

        return;
    }
}

var myobj = new AdminClass();

console.log(myobj.getStock());

//console.log(obj.numberOfBooks);

//console.log(obj.defineFine());

console.log(myobj.removeLibrarian("Ramu"));

console.log(myobj.reduceBookCount());

console.log(myobj.getStock());

myobj.increaseBookCount();

console.log(myobj.getStock());