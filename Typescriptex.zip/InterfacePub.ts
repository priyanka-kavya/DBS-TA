export interface Inter
{
    Talk():string;
    Walk():string;
}