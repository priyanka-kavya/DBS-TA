To start the json server,
1. In the node js command prompt, traverse to the directory where the json file exists
2. Install json-server through npm
   >npm install json-server -g
3. Start the json-server
   > json-server --watch Customers.json 
