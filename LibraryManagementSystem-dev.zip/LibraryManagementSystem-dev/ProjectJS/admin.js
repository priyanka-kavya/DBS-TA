function Admin()
{
    var username = "admin1";
    var pass = "password";

    this.numberOfBooks = 20;

    this.delayFine = 10;

    this.addLibrarian = function()
    {
        //console.log("New Librarian Added");

        return "New Librarian Added";
    }

    this.removeLibrarian = function(librarian)
    {
        //console.log("Existing Librarian Removed");

        return librarian + " Librarian Removed";
    }

    this.defineFine = function()
    {
        return "The delay fine is Rs. " + this.delayFine + " per day for late submissions";
    }

    this.getStock = function()
    {
        return "The number of books available are " + this.numberOfBooks;
    }

    this.reduceBookCount = function()
    {
        this.numberOfBooks = this.numberOfBooks - 1;

        return "Now the number of books are " + this.numberOfBooks;
    }
    
    this.increaseBookCount = function()
    {
        this.numberOfBooks = this.numberOfBooks + 1;

        return;
    }
}

var obj = new Admin();

console.log(obj.getStock());

//console.log(obj.numberOfBooks);

//console.log(obj.defineFine());

console.log(obj.removeLibrarian("Ramu"));

console.log(obj.reduceBookCount());

console.log(obj.getStock());

obj.increaseBookCount();

console.log(obj.getStock());