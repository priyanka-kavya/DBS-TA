import {Rectangle} from "./rectangle"
import {Circle} from "./circle"
import {Rtriangle} from "./Rtriangle"

var obj=new Circle(12);

console.log("Area is "+obj.Area());
console.log("Perimeter is "+obj.perimeter());

var obj1 = new Rectangle(2,5);

console.log("Area of reactangle is "+obj1.Area());

console.log("Perimeter of rectangle is "+obj1.perimeter());

var obj2 = new Rtriangle(3,4);

console.log("Area of R-Triangle is "+obj2.Area());


console.log("Perimeter of R-Triangle is "+obj2.perimeter());
