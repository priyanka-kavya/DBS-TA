var i = 5;
console.log((i % 2 == 0 ? "it is even" : "it is odd"));
