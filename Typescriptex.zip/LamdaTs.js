function fooTrad(x) {
    x = x + 10;
    console.log(x);
}
var fooInterm = function (x) {
    x = x + 10;
    console.log(x);
};
var foo = function (x) {
    x = x + 10;
    console.log(x);
};
console.log("Lamda functions");
foo(100);
fooTrad(20);
fooInterm(30);
var dosome = function (y) { return function (x) { return y * y * x; }; };
console.log(dosome(3)(5));
