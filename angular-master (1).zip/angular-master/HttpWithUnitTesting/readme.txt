Please check the following for unit testing purposes
1. HttpAsService Service
2. HttpPromiseL1 Component

For understanding calls using HttpClient, the rest of the files can be referred.
