Look at the configurations in angular.json in the configuration section
