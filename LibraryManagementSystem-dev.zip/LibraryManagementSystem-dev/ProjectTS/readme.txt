This folder contains all the project files in TypeScript
