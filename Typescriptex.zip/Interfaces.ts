import {Inter} from './InterfacePub'

export class Person implements Inter{
    constructor(pName:string,pAge:number){
        this.Name=pName;
        this.age=pAge;
    }
    Name:string;
    protected age:number;
    Gender:any[]=["Male","Female"];
    Aadhar:string;
    public Walk():string { return "I am walking"};
    public Talk():string { return "I am Talking"};
}
export class Employee extends Person{
    constructor(pName:string,pAge:number, pSalary:number,pDept:string)
    {
        super(pName,pAge);
        this.Salary=pSalary;
        this.Department=pDept;
        this.EmpID=this.GenerateRand();
        
    }
    static someNumber:number = 101;
    public EmpID:number;
    public Department:string;
    private Salary:number;

    private GenerateRand(){
        return Math.random() * 1000 + Employee.someNumber;
    }
    GetAge()
    {
        return this.age;
    }
    GetSalary(){
        return this.Salary;
    }

}

var Kavya = new Employee("Kavya",20,700000,"CSe");
console.log(Kavya.GetAge());
var res = Kavya.Talk();
console.log(res);