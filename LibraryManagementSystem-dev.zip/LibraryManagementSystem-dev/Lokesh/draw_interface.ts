export interface Shape
{
    draw():string;

    area():string;
}