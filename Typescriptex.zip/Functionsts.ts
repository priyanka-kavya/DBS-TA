function funWithRest(p1:string,
    ptitle:string = "In function funWithRest",
    extras?:any[],...members:string[])
    {
        console.log("P1:  "+p1);
        console.log("Ptitle: "+ptitle);
        console.log("Optional Param: "+extras);
        console.log("Printing extras: ");
       /* for(let ind=0;ind < members.length;ind++)
        {
            console.log(members[ind]);
        }*/
        console.log(members);
    }
    //funWithRest("Kavya");
    //funWithRest("Kavya","Priyanka",["ExtraP","ExtraP2"],"Arg1","Arg2");
    funWithRest("Kavya",undefined,[],"Mem1");

