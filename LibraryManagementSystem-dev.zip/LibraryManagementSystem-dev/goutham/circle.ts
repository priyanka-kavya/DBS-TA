import {ShapeIA} from "./shapeI"

export class Circle implements ShapeIA
{
	Radius:number;
	constructor(pRadius:number)
	{
	   this.Radius=pRadius;
	}
public Area():number
{
	return Math.PI*this.Radius*this.Radius;
}
public perimeter():number
{
return 2*Math.PI*this.Radius;
}
} 
