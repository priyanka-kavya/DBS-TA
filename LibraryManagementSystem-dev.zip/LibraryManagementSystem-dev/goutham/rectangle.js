"use strict";
exports.__esModule = true;
var Rectangle = /** @class */ (function () {
    function Rectangle(pLength, pBreadth) {
        this.Length = pLength;
        this.Breadth = pBreadth;
    }
    Rectangle.prototype.Area = function () {
        return this.Length * this.Breadth;
    };
    Rectangle.prototype.perimeter = function () {
        return 2 * (this.Length + this.Breadth);
    };
    return Rectangle;
}());
exports.Rectangle = Rectangle;
