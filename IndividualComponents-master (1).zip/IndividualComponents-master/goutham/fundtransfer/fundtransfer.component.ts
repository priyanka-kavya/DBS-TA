import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
