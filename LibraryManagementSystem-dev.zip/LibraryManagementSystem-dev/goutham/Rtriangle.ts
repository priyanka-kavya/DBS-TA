import {ShapeIA} from "./shapeI"

export class Rtriangle implements ShapeIA
{
        Base:number;
        Height:number;
constructor(pBase:number,pHeight:number){this.Base=pBase;this.Height=pHeight;}
public Area():number
{
        return 0.5*this.Height*this.Base;
}
public perimeter():number
{
        return this.Base+this.Height+(Math.sqrt(this.Base*this.Base+this.Height*this.Height));
}


}
