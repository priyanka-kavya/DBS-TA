import {ShapeIA} from "./shapeI"

export class Rectangle implements ShapeIA
{
	Length:number;
	Breadth:number;
constructor(pLength:number,pBreadth:number){this.Length=pLength;this.Breadth=pBreadth;}
public Area():number
{
	return this.Length*this.Breadth;
}
public perimeter():number
{
	return 2*(this.Length+this.Breadth);
}


}
