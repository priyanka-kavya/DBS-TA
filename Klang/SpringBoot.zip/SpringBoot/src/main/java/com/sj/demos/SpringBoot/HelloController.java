/**
 * 
 */
package com.sj.demos.SpringBoot;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Abridge Solutions
 *
 */
@Controller
@RequestMapping("/hello")
public class HelloController {
	@RequestMapping("/hi")
	public String sayHello(){
		return("Hello Goutham");
	}
	
	@RequestMapping("/hi2")
	public @ResponseBody String sayHi(){
		return "Hi lokesh";
	}

}
