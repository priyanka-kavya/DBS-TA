function funWithRest(p1, ptitle, extras) {
    if (ptitle === void 0) { ptitle = "In function funWithRest"; }
    var members = [];
    for (var _i = 3; _i < arguments.length; _i++) {
        members[_i - 3] = arguments[_i];
    }
    console.log("P1:  " + p1);
    console.log("Ptitle: " + ptitle);
    console.log("Optional Param: " + extras);
    console.log("Printing extras: ");
    /* for(let ind=0;ind < members.length;ind++)
     {
         console.log(members[ind]);
     }*/
    console.log(members);
}
//funWithRest("Kavya");
//funWithRest("Kavya","Priyanka",["ExtraP","ExtraP2"],"Arg1","Arg2");
funWithRest("Kavya", undefined, [], "Mem1");
