function fooTrad(x:number)
{
    x=x+10;
    console.log(x);
}
var fooInterm = function(x:number)
 {
     x=x+10; 
     console.log(x);
}
var foo = (x:number) => {
    x=x+10;
    console.log(x);
}
console.log("Lamda functions");
foo(100);
fooTrad(20);
fooInterm(30);

var dosome:any = (y) =>(x) => y*y*x;


console.log(dosome(3)(5));
