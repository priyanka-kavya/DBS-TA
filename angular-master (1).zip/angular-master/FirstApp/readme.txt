Contains component creation, directives, ng forms, rforms, property binding, event binding, directive binding, expression binding
