package com.sj.demos.SpringBoot.DAO;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.stereotype.Repository;

import com.sj.demos.SpringBoot.model.User;


@Repository
public class UserDaoClass implements UserDAO {

	ArrayList<User> arraylist;
	
	UserDaoClass(){
		
		arraylist = new ArrayList<User>();
	}
	
	@Override
	public User getUserByID(int id) {
		// TODO Auto-generated method stub
		for(User u:arraylist)
		{
			if(u.getId()  == id)
			{
				return u;
			}
		}
		return null;
	}

	@Override
	public Collection<User> getAll() {
		// TODO Auto-generated method stub
		return arraylist;
	}

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		arraylist.add(user);
		return user;
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		for(User u:arraylist)
		{
			if(u.getId()  == user.getId())
			{
				u.setId(user.getId());
				u.setName(user.getName());
				return u;
			}
		}
		return null;

	}

	@Override
	public String deleteUser(int id) {
		// TODO Auto-generated method stub
		for(User u: arraylist) {
			if(u.getId() == id)
			{
				arraylist.remove(u);
				return "Deleted user";
			}
		
		}
		return "USer not found";	
		
		
	}

}
