import {Circle} from './draw_circle'

import {Rectangle} from './draw_rectangle'

import {Square} from './draw_square'

var cir = new Circle(5);

console.log(cir.draw());

console.log(cir.area());

var rect = new Rectangle(10, 5);

console.log(rect.draw());

console.log(rect.area());

var sqr = new Square(5, 5);

console.log(sqr.draw());

console.log(sqr.area());