package com.sj.demos.SpringBoot.controller;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sj.demos.SpringBoot.DAO.UserDAO;
import com.sj.demos.SpringBoot.DAO.UserDaoClass;
import com.sj.demos.SpringBoot.model.User;

@RestController
@RequestMapping("/users")

public class UserController{
	
	@Autowired
	UserDaoClass udao;
	
	
	@GetMapping("/getbyid/{id}")
	public User getUserByID(@PathVariable int id)
	{
		return udao.getUserByID(id);
	}
	
	@RequestMapping("/getall")
	public Collection<User> getAll(){
	
		return udao.getAll();
	}
	
	@PostMapping("/createuser")
	public User createUser(@RequestBody User user) {
		// TODO Auto-generated method stub
		return udao.createUser(user);
	}

	
	
	@PostMapping("/updateuser")
	public User updateUser(@RequestBody User user) {
		// TODO Auto-generated method stub
		return udao.updateUser(user);
	}
	
	@PostMapping("deleteuser")
	public String deleteUser(@RequestBody int id) {
		// TODO Auto-generated method stub
		return udao.deleteUser(id);
	}

}
