import {Shape} from './draw_interface'

export class Circle implements Shape
{
    Radius:number;
    constructor(radius:number)
    {
        this.Radius = radius;
    }

    draw():string
    {
        return "Drawing a Circle with radius " + this.Radius;
    }

    area():string
    {
        var ar:number = 2*this.Radius*Math.PI;

        return "The area is " + ar;
    }
}