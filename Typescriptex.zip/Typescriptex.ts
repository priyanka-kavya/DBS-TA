function HaveFun(partyName:String):string
{
    return "NiceParty :"+partyName;
}
var feedback = HaveFun("Freshers party");
console.log(feedback);