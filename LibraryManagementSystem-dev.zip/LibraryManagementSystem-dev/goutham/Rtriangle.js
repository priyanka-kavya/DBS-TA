"use strict";
exports.__esModule = true;
var Rtriangle = /** @class */ (function () {
    function Rtriangle(pBase, pHeight) {
        this.Base = pBase;
        this.Height = pHeight;
    }
    Rtriangle.prototype.Area = function () {
        return 0.5 * this.Height * this.Base;
    };
    Rtriangle.prototype.perimeter = function () {
        return this.Base + this.Height + (Math.sqrt(this.Base * this.Base + this.Height * this.Height));
    };
    return Rtriangle;
}());
exports.Rtriangle = Rtriangle;
