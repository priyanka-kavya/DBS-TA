import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pwa-page-not-found',
  template: `
    <h3>page-not-found</h3>
  `,
  styles: []
})
export class PageNotFoundComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
