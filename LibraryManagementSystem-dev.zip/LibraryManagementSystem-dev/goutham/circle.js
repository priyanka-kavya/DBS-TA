"use strict";
exports.__esModule = true;
var Circle = /** @class */ (function () {
    function Circle(pRadius) {
        this.Radius = pRadius;
    }
    Circle.prototype.Area = function () {
        return Math.PI * this.Radius * this.Radius;
    };
    Circle.prototype.perimeter = function () {
        return 2 * Math.PI * this.Radius;
    };
    return Circle;
}());
exports.Circle = Circle;
