package com.sj.demos.SpringBoot.DAO;

import java.util.Collection;

import com.sj.demos.SpringBoot.model.User;

public interface UserDAO {

	public User getUserByID(int id);
	public Collection<User> getAll();
	public User createUser(User user);
	public User updateUser(User user);
	public String deleteUser(int id);
	
	
}
