import {Shape} from './draw_interface'

export class Square implements Shape
{
    Length:number;
    Breadth:number;

    constructor(side_a:number, side_b:number)
    {
        //super(side_a, side_b);
        this.Length = side_a;
        this.Breadth = side_b;
    }

    draw():string
    {
        return "Drawing Square with Length : " + this.Length + " & Breadth : " + this.Breadth;
    }

    area():string
    {
        var ar = this.Length*this.Breadth;

        return "The area of the Square : " + ar;
    }
}