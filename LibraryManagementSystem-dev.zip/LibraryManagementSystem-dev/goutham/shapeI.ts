export interface ShapeIA
{
Area():number;
perimeter():number;
}
